"""Script to list all resolvable URL pattern names and their corresponding path patterns.
Place this file in the same directory as your Django manage.py file.
Set DJANGO_SETTINGS_MODULE in your environment as appropriate, or update the setting below.
Then simply run "python list_urlpatterns.py"!
"""
import os
import re
from django.core.management.base import BaseCommand

from django.core.wsgi import get_wsgi_application
from django.urls import resolve, get_resolver, URLPattern, URLResolver
from django.urls.exceptions import Resolver404

from nautobot_bgp_models.api.urls import urlpatterns as bgpurls

DISALLAWED_CHARS = "^$"

application = get_wsgi_application()
resolver = get_resolver()

def list_url_paths(patterns_list, path_so_far="/"):
    """Recursively yield a list of all registered URL paths in this Django project."""
    for item in patterns_list:
        if isinstance(item, URLPattern):
            yield path_so_far + str(item.pattern)
        elif isinstance(item, URLResolver):
            # Recurse!
            yield from list_url_paths(item.url_patterns, path_so_far + str(item.pattern))


class Command(BaseCommand):
    """Print all URL paths."""

    help = "Print all URL paths."


    def handle(self, *args, **kwargs):
        """Print all URL paths."""

        # url_paths = list_url_paths(bgpurls)
        url_paths = list_url_paths(resolver.url_patterns)

        pairs = []
        for path in url_paths:
            try:
                path = re.sub(r"\<uuid\:.*\>", "d6d98b88-c866-4496-9bd4-de7ba48d0f52", path)
                path = re.sub(r"\<slug\:.*\>", "myslug", path)
                path = re.sub(r"\<int\:.*\>", "123456", path)
                path = re.sub(r"\<str\:.*\>", "mystring", path)
                path = re.sub(r"[\^\$]*", "", path)
                
                match = resolve(path)
            except Resolver404:
                import pdb
                pdb.set_trace()
                continue
            # Skip un-named paths, as we're only interested in those that have names
            if match.url_name is None:
                continue
            pairs.append((match.view_name, path))

        for view_name, path in sorted(pairs):
            print("{:50} {}".format(view_name, path))