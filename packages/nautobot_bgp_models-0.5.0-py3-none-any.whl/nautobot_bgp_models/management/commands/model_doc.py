"""Generate documentation for all models."""
import inspect
import importlib
from collections import defaultdict
from dataclasses import dataclass

from django.db.models import Model

from jinja2 import Template

from django.core.management.base import BaseCommand
from django.conf import settings

from rich.console import Console
from rich.table import Table

from nautobot.core.views import generic
from nautobot.extras.registry import registry

FEATURES_LIST = [
    "custom_fields",
    "custom_links",
    "custom_validators",
    "export_templates",
    "graphql",
    "relationships",
    "webhooks",
]

UI_LIST = [
    "view",
    "listview",

]

VIEWS_LIST = {
    "View": {
        "base_class": generic.ObjectListView,
        "url": "{model_name}"
    },
    "ListView": {
        "base_class": generic.ObjectListView,
        "url": "{model_name}_list"
    },
    "EditView": {
        "base_class": generic.ObjectEditView,
        "url": "{model_name}_add"
    }
}


# class PeeringRoleListView(generic.ObjectListView):
#     """List/table view of PeeringRole records."""

#     queryset = models.PeeringRole.objects.all()
#     table = tables.PeeringRoleTable
#     filterset = filters.PeeringRoleFilterSet
#     filterset_form = forms.PeeringRoleFilterForm
#     action_buttons = ("add", "import", "export")


# class PeeringRoleView(generic.ObjectView):
#     """Detail view of a single PeeringRole."""

#     queryset = models.PeeringRole.objects.all()


# class PeeringRoleEditView(generic.ObjectEditView):
#     """Create/edit view for a PeeringRole."""

#     queryset = models.PeeringRole.objects.all()
#     model_form = forms.PeeringRoleForm


# class PeeringRoleDeleteView(generic.ObjectDeleteView):
#     """Delete view for a PeeringRole."""

#     queryset = models.PeeringRole.objects.all()


# class PeeringRoleBulkImportView(generic.BulkImportView):
#     """Bulk-importing view for multiple PeeringRoles."""

#     queryset = models.PeeringRole.objects.all()
#     model_form = forms.PeeringRoleCSVForm
#     table = tables.PeeringRoleTable


# class PeeringRoleBulkEditView(generic.BulkEditView):
#     """Bulk-editing view for multiple PeeringRoles."""

#     queryset = models.PeeringRole.objects.all()
#     filterset = filters.PeeringRoleFilterSet
#     table = tables.PeeringRoleTable
#     form = forms.PeeringRoleBulkEditForm


# class PeeringRoleBulkDeleteView(generic.BulkDeleteView):
#     """Bulk-deleting view for multiple PeeringRoles."""

#     queryset = models.PeeringRole.objects.all()
#     filterset = filters.PeeringRoleFilterSet
#     table = tables.PeeringRoleTable



    # path("peering-roles/", views.PeeringRoleListView.as_view(), name="peeringrole_list"),
    # path("peering-roles/add/", views.PeeringRoleEditView.as_view(), name="peeringrole_add"),
    # path("peering-roles/import/", views.PeeringRoleBulkImportView.as_view(), name="peeringrole_import"),
    # path("peering-roles/edit/", views.PeeringRoleBulkEditView.as_view(), name="peeringrole_bulk_edit"),
    # path("peering-roles/delete/", views.PeeringRoleBulkDeleteView.as_view(), name="peeringrole_bulk_delete"),
    # path("peering-roles/<uuid:pk>/", views.PeeringRoleView.as_view(), name="peeringrole"),
    # path("peering-roles/<uuid:pk>/edit/", views.PeeringRoleEditView.as_view(), name="peeringrole_edit"),
    # path("peering-roles/<uuid:pk>/delete/", views.PeeringRoleDeleteView.as_view(), name="peeringrole_delete"),
    # path(
    #     "peering-roles/<uuid:pk>/changelog/",
    #     ObjectChangeLogView.as_view(),
    #     name="peeringrole_changelog",
    #     kwargs={"model": models.PeeringRole},
    # ),


@dataclass
class FeatureAnalysis:

    name: str
    enabled: bool


@dataclass
class ModelAnalysis:
    app_name: str
    model_name: str
    model = None

    filterset_name: str = "{model_name}FilterSet"
    form_name: str = "{model_name}Form"
    filterform_name: str = "{model_name}FilterForm"
    csvform_name: str = "{model_name}CSVForm"

    features: dict = defaultdict(FeatureAnalysis)
    ui: dict = defaultdict()

    has_custom_fields: bool = False
    has_custom_links: bool = False
    has_custom_validators: bool = False
    has_export_templates: bool = False
    has_graphql: bool = False
    has_relationships: bool = False
    has_webhooks: bool = False


def find_all_models_for(app_name, include_abstract=False):

    models = []
    mod_models = importlib.import_module(f"{app_name}.models")

    for attr_name in dir(mod_models):

        attr = getattr(mod_models, attr_name)
        if not inspect.isclass(attr) or not issubclass(attr, Model):
            continue
            
        if attr._meta.app_label != app_name:
            continue

        if not include_abstract and attr._meta.abstract:
            continue

        # print(f"Found Model {attr_name}")
        models.append(attr)
    
    return models

class Command(BaseCommand):
    """Command to generate base data."""

    help = "Generate documentation for all models in a given Nautobot App/Plugin."

    def add_arguments(self, parser):
        """Add count argument to generate_pops command."""
        parser.add_argument(
            "--app",
            type=str,
            default="nautobot_bgp_models"
        )

    def handle(self, *args, **kwargs):
        """Generate documentation for all models in a given Nautobot App/Plugin."""

        app_name = kwargs["app"]

        table = Table(title=f"Models for {app_name} app/plugin")

        models = find_all_models_for(app_name)

        table.add_column("Model", no_wrap=True)
        table.add_column("Description" )

        for feature in FEATURES_LIST:
            table.add_column(feature)

        for model in models:

            data = defaultdict(lambda: "N")
            model_name = model._meta.model_name

            for feature in FEATURES_LIST:
                
                if app_name not in registry["model_features"][feature]:
                    continue

                if model_name in registry["model_features"][feature][app_name]:
                    data[feature] = "Y"

            table.add_row(
                model.__name__,
                model.__doc__,
                data["custom_fields"],
                data["custom_links"],
                data["custom_validators"],
                data["export_templates"],
                data["graphql"],
                data["relationships"],
                data["webhooks"],
            )

        console = Console()
        console.print(table)
            
